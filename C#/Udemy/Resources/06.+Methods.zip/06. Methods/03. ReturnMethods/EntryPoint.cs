﻿using System;

class EntryPoint
{
    static void Main()
    {
        int resultFromAddition = Addition(Addition(1, 2), Addition(4, 5));

        Console.WriteLine(resultFromAddition);

        int[] sortedNumbers = SortThreeNumbers(46, 155, 92);

        foreach (var item in sortedNumbers)
        {
            Console.WriteLine(item);
        }
    }

    static int[] SortThreeNumbers(int a, int b, int c)
    {
        int[] sortedIntegers = new int[3];

        if ((a < b) && (a < c))
        {
            sortedIntegers[0] = a;

            if (b < c) // c > b > a
            {
                sortedIntegers[1] = b;
                sortedIntegers[2] = c;
            }
            else // b > c > a
            {
                sortedIntegers[1] = c;
                sortedIntegers[2] = b;
            }
        }
        else if ((b < a) && (b < c))
        {
            sortedIntegers[0] = b;

            if (a < c) // c > a > b
            {
                sortedIntegers[1] = a;
                sortedIntegers[2] = c;
            }
            else // a > c > b
            {
                sortedIntegers[1] = c;
                sortedIntegers[2] = a;
            }
        }
        else if ((c < a) && (c < b))
        {
            sortedIntegers[0] = c;

            if (a < b) // a > b > c
            {
                sortedIntegers[1] = a;
                sortedIntegers[2] = b;
            }
            else // b > a > c
            {
                sortedIntegers[1] = b;
                sortedIntegers[2] = a;
            }
        }

        return sortedIntegers;
    }

    static int Addition(int firstNumber, int secondNumber)
    {
        int result = firstNumber + secondNumber;

        return result;
    }
}
