﻿using System;

class EntryPoint
{
    static void Main()
    {
        Console.WriteLine("Before The Methods");
        PrintingNames();
        PrintingNames();
        Console.WriteLine("Inbetween The Methods");
        PrintingNames();
        PrintingNames();
        Console.WriteLine("After The Methods");
    }

    static void PrintingNames()
    {
        Console.Write("My name is ");
        Console.Write("Tod Vachev and I am ");
        Console.Write("learning C#\n");
    }
}