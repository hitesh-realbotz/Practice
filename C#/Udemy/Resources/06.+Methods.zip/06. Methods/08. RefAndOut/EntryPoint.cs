﻿using System;

class EntryPoint
{
    static void Main()
    {
        AreaAndPerimeterOfRectangle(5, 10, out double area, out double perimeter);

        Console.WriteLine($"The Area is {area}\nThe Perimeter is {perimeter}");
    }

    static void AreaAndPerimeterOfRectangle(double sideA, double sideB, out double area, out double perimeter)
    {
        area = sideA * sideB;
        perimeter = 2 * sideA + 2 * sideB;
    }
}