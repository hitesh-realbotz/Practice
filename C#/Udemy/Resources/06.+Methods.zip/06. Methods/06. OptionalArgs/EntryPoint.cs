﻿using System;

class EntryPoint
{
    static void Main()
    {
        Console.WriteLine(Multi(2, 3));

        ConnectToDB("Tod", "123456");

        Console.WriteLine(Sum(5, 6));
    }

    static int Sum(int firstNumber, int secondNumber, int thirdNumber = 0)
    {
        return firstNumber + secondNumber + thirdNumber;
    }

    static int Multi(int firstNumber, int secondNumber, int thirdNumber = 1)
    {
        return firstNumber * secondNumber * thirdNumber;
    }

    static void ConnectToDB(string username, string password, string ipAddress = "127.0.0.1")
    {
        Console.WriteLine($"Hello {username}, connecting to {ipAddress}, please wait ...");
    }
}