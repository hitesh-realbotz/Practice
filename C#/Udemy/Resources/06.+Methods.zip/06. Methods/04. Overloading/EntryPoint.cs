﻿using System;

// Square side * side
// Rectangle sideA * sideB
// 
//

class EntryPoint
{
    static void Main()
    {
        PrintNames("Tod", "Vachev", ConsoleColor.Red);
        PrintNames("Tod", "MiddleName", "Vachev");

        Console.WriteLine(Area(1, 1, 1));

    }

    static double Area(double side)
    {
        return side * side;
    }

    static double Area(double sideA, double sideB)
    {
        return sideA * sideB;
    }

    static double Area(double sideA, double sideB, double sideC)
    {
        double s = Sum(sideA, sideB, sideC) / 2;
        double area = Math.Sqrt(s * (s - sideA) * (s - sideB) * (s - sideC));

        return area;
    }

    static void PrintNames(string firstName, string lastName)
    {
        Console.WriteLine($"My name is {firstName} {lastName}.");
    }

    static void PrintNames(string firstName, string middleName, string lastName)
    {
        Console.WriteLine($"My name is {firstName} {middleName} {lastName}.");
    }

    static void PrintNames(string firstName, string lastName, ConsoleColor color)
    {
        Console.ForegroundColor = color;
        Console.WriteLine($"My name is {firstName} {lastName}.");
        Console.ResetColor();
    }

    static int Sum(int firstNumber, int secondNumber)
    {
        return firstNumber + secondNumber;
    }

    static double Sum(double firstNumber, double secondNumber, double thirdNumber)
    {
        return firstNumber + secondNumber + thirdNumber;
    }

    static int Sum(int firstNumber, int secondNumber, int thirdNumber, int fourthNumber)
    {
        return firstNumber + secondNumber + thirdNumber + fourthNumber;
    }
}
