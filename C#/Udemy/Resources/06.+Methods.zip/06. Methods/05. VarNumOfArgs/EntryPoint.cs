﻿using System;

class EntryPoint
{
    static void Main()
    {
        int firstNumber = 5;
        int secondNumber = 6;
        int thirdNumber = 7;
        string firstName = "Tod";
        string lastName = "Vachev";
        Console.WriteLine("{0} {1} {2} {0} {1}", firstNumber, secondNumber, thirdNumber);

        WriteLinePlaceholders("[1] [0]", firstName, lastName);
    }

    static void WriteLinePlaceholders(string text, params string[] variables)
    {
        string newText = string.Empty;
        int placeholderIndex = 0;

        for (int i = 0; i < text.Length; i++)
        {
            if (text[i].ToString() == "[")
            {
                placeholderIndex = int.Parse(text[i + 1].ToString());
                newText += variables[placeholderIndex];
                i += 2;
            }
            else
            {
                newText += text[i];
            }
        }

        Console.WriteLine(newText);
    }

    static int Perimeter(params int[] numbers)
    {
        int sum = 0;

        for (int i = 0; i < numbers.Length; i++)
        {
            sum += numbers[i];
        }

        return sum;
    }
}
