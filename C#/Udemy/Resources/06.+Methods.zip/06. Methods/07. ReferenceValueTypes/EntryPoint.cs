﻿using System;

class EntryPoint
{
    static void Main()
    {
        int number = 10;
        int secondNumber = number;
        number = 15;
        int[] array = { 1, 2, 3, 4, 5 };
        int[] secondArray = array;

        array[2] = 10;
        
        Console.WriteLine(secondNumber);
        Console.WriteLine(secondArray[2]);

        ModifyArray(number);

        Console.WriteLine(number);
    }

    static void ModifyArray(int intValue)
    {
        intValue++;
    }
}