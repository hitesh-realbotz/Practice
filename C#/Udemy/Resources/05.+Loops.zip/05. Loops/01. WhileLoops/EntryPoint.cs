﻿using System;

class EntryPoint
{
    static void Main()
    {

    }
}