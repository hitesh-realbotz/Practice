﻿using System;

class EntryPoint
{
    static void Main()
    {
        int number = Convert.ToInt32(Console.ReadLine());
        int secondNumber = Convert.ToInt32(Console.ReadLine());

        if (secondNumber != 0)
        {
            int result = number / secondNumber
        }

        Console.WriteLine("After the try/catch block");
    }
}