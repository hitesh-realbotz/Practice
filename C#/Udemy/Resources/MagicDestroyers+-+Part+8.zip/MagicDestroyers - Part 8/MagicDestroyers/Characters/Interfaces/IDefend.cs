﻿namespace MagicDestroyers.Characters.Interfaces
{
    public interface IDefend
    {
        int Defend();
    }
}
