﻿namespace MagicDestroyers.Equipment.Interfaces
{
    public interface IBuff
    {
        void Buff();
    }
}
