﻿namespace MagicDestroyers.Equipment.Armors.Heavy
{
    public abstract class Heavy : Armor
    {

    }
}
