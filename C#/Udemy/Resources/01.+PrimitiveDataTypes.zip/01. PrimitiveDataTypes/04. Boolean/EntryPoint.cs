﻿class EntryPoint
{
    static void Main()
    {
        int firstNumber = 4;
        int secondNumber = 6;

        bool isTheCookieJarEmpty = true;
        bool isTheFirstIntegerSmallerThanTheSecond = firstNumber < secondNumber;

        System.Console.WriteLine(isTheFirstIntegerSmallerThanTheSecond);
    }
}