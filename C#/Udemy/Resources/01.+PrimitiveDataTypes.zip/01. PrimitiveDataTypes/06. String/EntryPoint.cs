﻿class EntryPoint
{
    static void Main()
    {
        string username = "admin";

        System.Console.WriteLine(username[4]);

    }
}