﻿using System;

namespace Variables
{
    class EntryPoint
    {
        static void Main()
        {
            int age = 26;
            string firstName = "Tod";
            string freeSpace = " ";

            Console.WriteLine(firstName + freeSpace + age);
        }
    }
}
