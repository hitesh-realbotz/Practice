﻿using System;

class EntryPoint
{
    static void Main()
    {
        Console.SetWindowSize(50, 20);
        Console.SetBufferSize(60, 30);
        Console.SetWindowPosition(5, 5);
        //Console.WindowHeight = 20;
        //Console.WindowWidth = 20;
        //Console.BufferHeight = 200;
        //Console.BufferWidth = 200;
        //Console.WindowLeft = 10;
        //Console.WindowTop = 10;
    }
}