USE coffee_store;
 
SELECT id, name, price, coffee_origin FROM products;

SELECT id, name AS coffee, price, coffee_origin AS country FROM products;

SELECT id, name coffee, price, coffee_origin country FROM products;