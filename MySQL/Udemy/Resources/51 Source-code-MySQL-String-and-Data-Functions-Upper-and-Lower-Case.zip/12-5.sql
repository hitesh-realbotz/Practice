USE cinema_booking_system;
 
-- Upper and Lower case.
 
-- SELECT upper(column1) AS new_column_name FROM table1;
-- SELECT lower(column1) AS new_column_name FROM table1;

SELECT name FROM rooms;

SELECT upper(name) AS name FROM rooms;

SELECT lower(name) AS name FROM rooms;