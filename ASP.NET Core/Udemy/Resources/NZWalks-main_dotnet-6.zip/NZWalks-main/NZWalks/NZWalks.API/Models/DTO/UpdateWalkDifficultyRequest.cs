﻿namespace NZWalks.API.Models.DTO
{
    public class UpdateWalkDifficultyRequest
    {
        public string Code { get; set; }
    }
}
