﻿namespace NZWalks.API.Models.DTO
{
    public class WalkDifficulty
    {
        public Guid Id { get; set; }
        public string Code { get; set; }
    }
}
